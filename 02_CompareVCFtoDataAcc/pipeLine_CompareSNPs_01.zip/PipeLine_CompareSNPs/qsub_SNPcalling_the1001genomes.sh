#!/bin/bash
#PBS -S /bin/bash
#PBS -P the1001genomes
#PBS -N SNPcalling
#PBS -V
#PBS -l walltime=48:00:00
#PBS -l select=1:ncpus=16:mem=48gb
#PBS -o log

#Input:  Prealigned BAM file  
#Output: VCF file generated after aligning to the reference TAIR10

cd /lustre/scratch/projects/the1001genomes/rahul/C7190ANXX_20150623B_demux_4_rd2_1
inFiles=(`ls *.bam`)
length=${#inFiles[@]}
count=0
for (( i=0; i<$length; i=i+1 ));do
	bash ~/MyScripts/SNPcalling/SNPcalling_UnalignedBAM_GATKvcf.sh ${inFiles[$i]} &
	count=$((count+1))
	if [ $(($count % 2)) = 0 ]
	then
		wait
#		bash the CompareSNPs file for the samples completed SNP calling
	fi
done
echo "Number of files: $count"
