#Plot number of variants to the t-statistic of the top hit
#and the regression

setwd("/media/pisupati.admin/hpc-SCRATCH/projects/the1001genomes/rahul/C7190ANXX_20150623B_demux_4_rd2_1/intermediate/quality_50/")
# Create a file NumberSNPs_samples.txt
# using a bash script
system("wc -l *.pos.txt|head -n -1 |tr -s ' '|sed 's/ /\t/g'|cut -f2,3|sed 's/.pos.txt$//' >NumberSNPs_samples.txt")


# things to be modified
numSNPs <- read.csv("NumberSNPs_samples.txt", header = F, sep = "\t")
AssignedAcc <- read.csv("../acc_table_rd2_1.txt", header = T, sep = "\t")
fileid <- "C7190ANXX_4#"

# Correction for changing the rows to coloumns
rows <- c("A","B","C","D","E","F","G","H")
cols <- c("1","2","3","4","5","6","7","8","9","10","11","12")
correctedAssAcc <- matrix(
  AssignedAcc$sample.description,
  nrow = 8,
  ncol = 12,
  dimnames = list(rows, cols))

#-------
allScoreFiles <- list.files(".", pattern = ".ScoreAcc.txt$")
Names <- character()
sampleRows <- character()
sampleCol <- character()
accAssigned <- character()
TopHitAcc <- character()
TopHitScore <- character()
TopHitAccSNPs <- character()
TopHitMatchedSNPs <- character()
ScoreSDs <- character()
ScoreNOs <- character()
SNPscalled <- character()
ChoiceAcc <- character()
for (file in allScoreFiles){
  ScoreAcc <- read.table(file, header = F)
  name <- sub(".ScoreAcc.txt","",file)
  #Converting the name of file into rows and columns
  tempnum <- as.numeric(strsplit(sub(fileid, "", name), "_")[[1]][1])-700
  tempidnum <- as.numeric(sub("50","",strsplit(sub(fileid, "", name), "_")[[1]][2]))
  tempid <- chartr("12345678","ABCDEFGH",sub("50","",strsplit(sub(fileid, "", name), "_")[[1]][2]))
  sampleRows <- c(sampleRows, tempid)
  sampleCol <- c(sampleCol, tempnum)
  Names <- c(Names, name)
  # accass <- AssignedAcc$sample.description[which(AssignedAcc$row == tempid & AssignedAcc$column == tempnum)]
  accass <- correctedAssAcc[tempidnum, tempnum]
  accAssigned <- c(accAssigned, accass)
  choicenum <- which(ScoreAcc$V1[order(-ScoreAcc$V4)] == accass)
  if (length(choicenum)){
    ChoiceAcc <- c(ChoiceAcc, choicenum)
  } else {
    ChoiceAcc <- c(ChoiceAcc, 'NA')
  }
  snps <- as.numeric(numSNPs$V1[which(numSNPs$V2 == name)])
  TopHitAcc <- c(TopHitAcc, ScoreAcc$V1[which(ScoreAcc$V4 == max(ScoreAcc$V4))])
  TopHitScore <- c(TopHitScore, as.numeric(max(ScoreAcc$V4)))
  TopHitAccSNPs <- c(TopHitAccSNPs, as.numeric(ScoreAcc$V3[which(ScoreAcc$V4 == max(ScoreAcc$V4))]))
  TopHitMatchedSNPs <- c(TopHitMatchedSNPs, as.numeric(ScoreAcc$V2[which(ScoreAcc$V4 == max(ScoreAcc$V4))]))
  ScoreAccSD = as.numeric((max(ScoreAcc$V4) - mean(ScoreAcc$V4))/sd(ScoreAcc$V4));
  ScoreAccNO = as.numeric(length(which(ScoreAcc$V4 > max(ScoreAcc$V4)-sd(ScoreAcc$V4))));
  ScoreSDs <- c(ScoreSDs, ScoreAccSD)
  ScoreNOs <- c(ScoreNOs, ScoreAccNO)
  SNPscalled <- c(SNPscalled, snps)
}
DF <- data.frame(FILENAME = Names, ROW = sampleRows, COL = sampleCol, AssignedAcccession = accAssigned,TopHitAccession = TopHitAcc, Score = as.numeric(TopHitScore), MatchedSNPs = as.numeric(TopHitMatchedSNPs), SNPsCalled = as.numeric(SNPscalled), SNPsinAcc  = as.numeric(TopHitAccSNPs), tStat  = as.numeric(ScoreSDs), TopHitsNumber = ScoreNOs, ChoiceofAcc = ChoiceAcc)
fix(DF)
#--------

write.csv(DF, file = "intermediate_corrected.csv")


