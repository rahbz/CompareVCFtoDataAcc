#  This is not a qsub script that is to be given directly, 
#run it on the node.

#Input:  Prealigned BAM file  
#Output: VCF file generated after aligning to the reference TAIR10

#Running the script
#bash ~/projects/the1001genomes/bharadwaj/potatoSkin_SNPCalling.sh //path//.bam

inFile=`echo $1|sed 's/\.bam$//'`
workingDIR=( $(pwd) )

# Change the unaligned BAM files to interleaved fastq
module load picard
java -jar /net/gmi.oeaw.ac.at/software/mendel/29_04_2013/software/picard/1.110/SamToFastq.jar I=$1 F=$inFile.fastq INTER=true


#Aligning the fastq using BWA
#might increase the number of working cores in bwa -- 8 or 16
module load BWA
#bwa index /lustre/scratch/users/rahul.pisupati/whole_genome_TAIR10/TAIR10_ARTH.fa
bwa mem -t 8 -p /lustre/scratch/users/rahul.pisupati/whole_genome_TAIR10/TAIR10_ARTH.fa $inFile.fastq > $inFile.sam 2> bwa.log

# SAM to BAM
module load SAMtools
samtools view -b -o $inFile.aligned.bam -S $inFile.sam
samtools sort $inFile.aligned.bam $inFile.sorted

#Adding ReadGroups to the BAM file
module load picard
java -jar /net/gmi.oeaw.ac.at/software/mendel/29_04_2013/software/picard/1.110/AddOrReplaceReadGroups.jar INPUT=$inFile.sorted.bam OUTPUT=$inFile.modified.bam ID=$inFile LB=temp PL=illumina PU=none SM=C7190

samtools index $inFile.modified.bam

#GATK for SNP calling
module load GATK
java -jar /net/gmi.oeaw.ac.at/software/mendel/29_04_2013/software/GATK/3.4-0-Java-1.8.0_45/GenomeAnalysisTK.jar -T HaplotypeCaller -R /lustre/scratch/users/rahul.pisupati/whole_genome_TAIR10/TAIR10_ARTH.fa -I $inFile.modified.bam --genotyping_mode DISCOVERY -o $inFile.vcf -nct 8

#a variant file is generated
# Running the python script to calculate the distance with the accessions


