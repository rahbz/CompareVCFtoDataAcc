#!/bin/bash
#PBS -S /bin/bash
#PBS -P the1001genomes
#PBS -N VCFcompare
#PBS -V
#PBS -l walltime=48:00:00
#PBS -l select=1:ncpus=8:mem=48gb
#PBS -o log

#Input:  VCF files generated after SNP calling
#Output: Compare accessions

cd /lustre/scratch/projects/the1001genomes/rahul/C7190ANXX_20150623B_demux_4_rd2_1/intermediate
inFiles=(`ls *.vcf`)
length=${#inFiles[@]}
count=1
for (( i=0; i<$length; i=i+1 ));do
	bash ~/MyScripts/03_CompareVCFtoDataAcc/potatoSkin_VCFfile_CompareSNPs.sh ${inFiles[$i]} 100 &
	count=$((count+1))
	if [ $(($count % 8)) = 0 ]
	then
		wait
	fi
done
