#!/bin/bash

inFile=`echo $1 | sed 's/\.vcf$//'`

#echo "Number of chromosomes $NoChrs"

qthres=$2

#Get the SNP positions into a file
grep -v '#' $1 | awk -v qth=$qthres 'length($4) == 1 && length($5) == 1 && $6 > qth {print $1 "\t" $2}'|sed 's/^Chr//' > $inFile.pos.txt
numSNP=`wc -l $inFile.pos.txt`

# Run the Rscript
module load R
Rscript ~/MyScripts/03_CompareVCFtoDataAcc/FindMatchingSNPpositions.R $inFile.pos.txt $inFile.matchedSNPs

# Run the python script with matched SNPs
module load numpy
module use /net/gmi.oeaw.ac.at/software/shared/nordborg_common/modulefiles/
module load pygwas

python ~/MyScripts/03_CompareVCFtoDataAcc/CalcHammingDist.py -t /lustre/scratch/users/rahul.pisupati/totalSNPsNum_1001genomes.txt -m $inFile.matchedSNPs -n $numSNP -o $inFile.ScoreAcc.txt

