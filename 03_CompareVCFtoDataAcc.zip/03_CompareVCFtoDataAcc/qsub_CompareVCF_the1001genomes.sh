#!/bin/bash
#PBS -S /bin/bash
#PBS -P the1001genomes
#PBS -N VCFcompare
#PBS -V
#PBS -l walltime=48:00:00
#PBS -l select=1:ncpus=16:mem=32gb
#PBS -o log

#Input:  VCF files generated after SNP calling
#Output: Compare accessions

#cd /lustre/scratch/projects/the1001genomes/rahul/01_C7190ANXX_20150623B_demux_4_rd2_1
#cd /lustre/scratch/projects/the1001genomes/rahul/02_C7190ANXX_20150623B_demux_5_rd2_2
#cd /lustre/scratch/projects/the1001genomes/rahul/03_C71EWANXX_20150609B_demux_3_rd3_1
#cd /lustre/scratch/projects/the1001genomes/rahul/04_C6KD7ANXX_20150327B_demux_2_rd1_2
#cd /lustre/scratch/projects/the1001genomes/rahul/05_C70WNANXX_20150520B_demux_8_rd4_3
#cd /lustre/scratch/projects/the1001genomes/rahul/06_C71EWANXX_20150609B_demux_2_rd4_1
#cd /lustre/scratch/projects/the1001genomes/rahul/07_C719TANXX_20150710B_demux_3_rd1_12
cd /lustre/scratch/projects/the1001genomes/rahul/F2s_fernando

inFiles=(`ls *.vcf`)
length=${#inFiles[@]}
count=0
for (( i=0; i<$length; i=i+1 ));do
	bash ~/MyScripts/03_CompareVCFtoDataAcc/potatoSkin_VCFfile_CompareSNPs.sh ${inFiles[$i]} 100 &
	count=$((count+1))
	if [ $(($count % 16)) = 0 ]
	then
		wait
	fi
done
wait
